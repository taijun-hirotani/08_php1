<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>物件情報登録</title>
</head>

<?php


?>

<body>
    <form method="post" action="write.php">

        <p>物件<input type="text" name="name" size="20"></p>
        <p>住所<input type="text" name="address" size="20"></p>
        <p>緯度<input type="text" name="lat" size="20"></p>
        <p>経度<input type="text" name="lng" size="20"></p>
        
        <p><input type="submit" value="送信"></p>
    </form>  
</body>
</html>

